                    ----------------------------
                        AFUWIN USER'S GUIDE
                    ----------------------------

INTRODUCTION
------------

    File Name          Description
    ---------------------------------------------------------------------------
    readme.txt         This file.
    Afuwin.exe         32/64-bit executable.
    Afuwin64.exe       pure 64-bit executable.
    Afuwingui.txt      32/64-bit WINDOWS GUI executable.
    amifldrv32.sys     32-bit driver for XP, Vista, Windows 7, Windows 8, 
		       Windows 8.1 or WinPE.
    amifldrv64.sys     64-bit driver for XP, Vista, Windows 7, Windows 8, 
		       Windows 8.1 or WinPE.
    ---------------------------------------------------------------------------

AFUWIN
-------

    Type 'Afuwin.exe'to see a list of available
    commands and flash your BIOS anyway your want.
