
void i2c_cmd_init();
void i2c_cmd_ack();
void i2c_cmd_read();
void i2c_cmd_write();
void i2c_cmd_readbyte();
void i2c_cmd_writebyte();
