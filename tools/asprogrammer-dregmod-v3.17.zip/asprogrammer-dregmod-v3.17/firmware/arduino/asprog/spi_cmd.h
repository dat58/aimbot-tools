void spi_cmd_read();
void spi_cmd_write();
void spi_cmd_init();
void spi_cmd_deinit();
